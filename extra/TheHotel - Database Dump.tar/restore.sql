--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "TheHotelDB";
--
-- Name: TheHotelDB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "TheHotelDB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE "TheHotelDB" OWNER TO postgres;

\connect "TheHotelDB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: notify_change(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.notify_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
PERFORM pg_notify('table_changed', TG_TABLE_NAME::regclass::text); 
RETURN NEW;
END;
$$;


ALTER FUNCTION public.notify_change() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookings (
    oid bigint NOT NULL,
    checked_in boolean DEFAULT false NOT NULL,
    from_date bigint NOT NULL,
    price double precision NOT NULL,
    to_date bigint NOT NULL,
    customer_oid bigint,
    room_oid bigint
);


ALTER TABLE public.bookings OWNER TO postgres;

--
-- Name: bookings_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bookings_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bookings_oid_seq OWNER TO postgres;

--
-- Name: bookings_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bookings_oid_seq OWNED BY public.bookings.oid;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    oid bigint NOT NULL,
    first_name character varying(50) NOT NULL,
    id_number bigint NOT NULL,
    last_name character varying(50) NOT NULL
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_oid_seq OWNER TO postgres;

--
-- Name: customers_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_oid_seq OWNED BY public.customers.oid;


--
-- Name: hotels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hotels (
    oid bigint NOT NULL,
    country character varying(50) NOT NULL,
    hotel_name character varying(50) NOT NULL,
    stars integer NOT NULL
);


ALTER TABLE public.hotels OWNER TO postgres;

--
-- Name: hotels_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hotels_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hotels_oid_seq OWNER TO postgres;

--
-- Name: hotels_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hotels_oid_seq OWNED BY public.hotels.oid;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    oid bigint NOT NULL,
    number_of_beds integer NOT NULL,
    room_number integer NOT NULL,
    hotel_oid bigint NOT NULL
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Name: rooms_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rooms_oid_seq OWNER TO postgres;

--
-- Name: rooms_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_oid_seq OWNED BY public.rooms.oid;


--
-- Name: bookings oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings ALTER COLUMN oid SET DEFAULT nextval('public.bookings_oid_seq'::regclass);


--
-- Name: customers oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN oid SET DEFAULT nextval('public.customers_oid_seq'::regclass);


--
-- Name: hotels oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotels ALTER COLUMN oid SET DEFAULT nextval('public.hotels_oid_seq'::regclass);


--
-- Name: rooms oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN oid SET DEFAULT nextval('public.rooms_oid_seq'::regclass);


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookings (oid, checked_in, from_date, price, to_date, customer_oid, room_oid) FROM stdin;
\.
COPY public.bookings (oid, checked_in, from_date, price, to_date, customer_oid, room_oid) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (oid, first_name, id_number, last_name) FROM stdin;
\.
COPY public.customers (oid, first_name, id_number, last_name) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: hotels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hotels (oid, country, hotel_name, stars) FROM stdin;
\.
COPY public.hotels (oid, country, hotel_name, stars) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (oid, number_of_beds, room_number, hotel_oid) FROM stdin;
\.
COPY public.rooms (oid, number_of_beds, room_number, hotel_oid) FROM '$$PATH$$/3350.dat';

--
-- Name: bookings_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookings_oid_seq', 1, true);


--
-- Name: customers_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_oid_seq', 27, true);


--
-- Name: hotels_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hotels_oid_seq', 2, true);


--
-- Name: rooms_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_oid_seq', 4, true);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (oid);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (oid);


--
-- Name: hotels hotels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotels
    ADD CONSTRAINT hotels_pkey PRIMARY KEY (oid);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (oid);


--
-- Name: hotels uk_42nuxcbwdcx8n9fter0bxhdqb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotels
    ADD CONSTRAINT uk_42nuxcbwdcx8n9fter0bxhdqb UNIQUE (hotel_name);


--
-- Name: rooms uk_7ljglxlj90ln3lbas4kl983m2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT uk_7ljglxlj90ln3lbas4kl983m2 UNIQUE (room_number);


--
-- Name: customers uk_r06t9h8n4ux62l3tdjp9vodft; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT uk_r06t9h8n4ux62l3tdjp9vodft UNIQUE (id_number);


--
-- Name: customers data_change_notification; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER data_change_notification AFTER INSERT OR DELETE OR UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.notify_change();


--
-- Name: rooms data_change_notification; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER data_change_notification AFTER INSERT OR DELETE OR UPDATE ON public.rooms FOR EACH ROW EXECUTE FUNCTION public.notify_change();


--
-- Name: bookings fk8wbi7obtldtnwg2pitbb1cvgn; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT fk8wbi7obtldtnwg2pitbb1cvgn FOREIGN KEY (room_oid) REFERENCES public.rooms(oid);


--
-- Name: bookings fk9b35si9btwrx6ut49ev02ib2j; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT fk9b35si9btwrx6ut49ev02ib2j FOREIGN KEY (customer_oid) REFERENCES public.customers(oid);


--
-- Name: rooms fkexkcqjh91nq4b33cywljcwhtd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT fkexkcqjh91nq4b33cywljcwhtd FOREIGN KEY (hotel_oid) REFERENCES public.hotels(oid);


--
-- PostgreSQL database dump complete
--

